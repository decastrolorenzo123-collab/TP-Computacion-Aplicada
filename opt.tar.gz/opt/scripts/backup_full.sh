#!/bin/bash

# backup_full.sh - Script de backup
# Uso: ./backup_full.sh <origen> <destino>

if [ "$1" = "-help" ]; then
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo ""
    echo "Crea un backup comprimido del directorio_origen en el directorio_destino"
    echo "El nombre del archivo incluye la fecha en formato YYYYMMDD"
    echo ""
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

if [ $# -lt 2 ]; then
    echo "Error: faltan argumentos"
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo "Tipear '$0 -help' para mas informacion"
    exit 1
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio de origen '$ORIGEN' no existe o no es accesible"
    exit 2
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio de destino '$DESTINO' no existe o no es accesible"
    exit 3
fi

FECHA=$(date +%Y%m%d)
NOMBRE_ORIGEN=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN" 2>/dev/null

if [ $? -ne 0 ]; then
    echo "Error: el backup fallo"
    exit 4
fi

echo "Backup creado correctamente: $DESTINO/$ARCHIVO"
exit 0
