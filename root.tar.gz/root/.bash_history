history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
apt upgrade
cp /etc/apt/sources.list /etc/apt/sources.list/bullseye.bak
ls /etc/apt/
cp etc/apt/sources.list/ /etc/apt/sources.list.bull
cp etc/apt/sources.list /etc/apt/sources.list.bull
cp /etc/apt/sources.list /etc/apt/sources.list.bull
ls /etc/apt
 > /etc/apt/sources.list
echo "deb http://deb.debian.org/debian/ bookworm main contrib non-free non-free-firmware" >> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian/ bookworm-updates main contrib non-free non-free-firmware" >> /etc/apt/sources.list
echo "deb http://security.debian.org/debian-security/ bookworm-security main contrib non-free non-free-firmware" >> /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt full-upgrade
cat /etc/debian_version
reboot
cat /etc/hostname
nano/etc/hostname
nano /etc/hostname
nano / etc/hostname
apt install nano
ping -c 4 8.8.8.8
 apt get-install nano
apt update
apt install nano
apt ping -c 4 deb.debian.org
ping -c 4 deb.debian.rog
ping -c 4 deb.debian.org
apt update
apd update
apt update
ping -c 2 cdn2-fastly.deb.debian.org
cat /etc/apt/sources.list
cp /etc/apt/sources.list /etc/apt.sources.list.bak
ls /etc/apt
ls -l /etc/apt/sources.list*"
















clear
wq
cp /etc/apt/sources.list /etc/apt/sources.list.bak
ls -l /etc/apt/sources.list*
apt update
nano
vi /etc/apt/sources.list
jobs
fg
cat /etc/apt/sources.list
cat > /etc/apt/sources.list << EOF
bullseye main contrib non-free
bulsseye-updates main contrib non-free
bullseye-security main contrib non-free
EOF

cat /etc/apt/sources.list
cp /etc/apt/sources.list.bak /etc/apt/sources.list
cat /etc/apt/sources.list
cp /etc/apt/sources.list.bak /etc/apt/sources.list
> /etc/apt/sources.list
 > /etc/apt/sources.list
cat /etc/apt/sources.list
echo "deb http://archive.debian.org/debian bullseye main contrib non-free" >> /etc/apt/sources.list
cat /etc/apt/sources.list
echo "deb http://archive.debian.org/debian/ bullseye-updates main contrib non-free" >> /etc/apt/sources.list
cat /etc/apt/sources.list
echo "deb http://archive.debian.org/debian-security/ bullseye-security main contrib non-free" >> /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
 > /etc/apt/sources.list
echo "deb https://archive.debian.org/debian/ bullseye main contrib non-free" >> /etc/apt/sources.list
echo "deb http://archive.debian.org/debian/ bulsseye-updates main contrib non-free" >> /etc/apt/sources.list
cat /etc/apt/sources.list
 > /etc/apt/sources.list
echo "deb http://archive.debian.org/debian/ bullseye main contrib non-free" >> /etc/apt/sources.list
echo "deb http://archive.debian.org/debian/ bullseye-updates main contrib non-free" >> /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt install nano
nano /etc/hostname
cat /etc/hostname
hostname TPServer
bash
uname -r
cat /etc/debian_version
poweroff
systemctl status ssh
apt install openssh-server
systemctl status ssh
ip addr
poweroff
nano /etc/ssh/sshd_config
systemctl restart ssh
grep PermitRootLogin /etc/ssh/sshd_config
ip adr
ip addr
systemctl status ssh
ssh-keygen -t rsta -b 4096 -f /root/.ssh/id-rsa
ssh-keygen -t rsa -b 4096 /root/.ssh/id-rsa
ssh-keygen -t rsa -b 4096 -f /root/.ssh/id_rsa
ls -l /root/.ssh
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
ls -l /root/.ssh/
cat /root/.ssh/id_rsa
nano /etc/ssh/sshd_config
head -20 /etc/ssh/sshd-config
head -20 /etc/ssh/sshd_config
grep- i "permitrootlogin" /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf
grep -i "permitrootlogin" /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*-conf
nano /etc/ssh/sshd_config
grep PermiRootLogin /etc/ssh/sshd_config
grep PermitRootLogin /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
ls /root/
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz -C /root/
mv /root/Material_Adicional_TPVMCA/index.php /root/
mv /root/Material:_Adicional_TPVMCA/logo.png /root/
mv /root/Material_Adicional_TPVMCA/logo.png /root/
mv /root/Material_Adicional_TPVMCA/db.sql /root/
ls /root/
apt isntall apache2 php libapache2-mod-php
apt install apache2 php libapache2-mod-php
SYSTEMCTL STATUS APACHE2
systemctl status apache2
rm /var/www/html/index.html
cp /root/indeax.php /var/www/html/
cp /root/index.php /var/www/html
cp /root/logo.png /var/www/html/
ls /var/www/html/
cat /root/index.php
a2query -m php8.2
tail -20 /var/log/apache2/error.log
apt install php-mysq1
apt install php-misq1
apt install php-mysql
systemctl restart apache2
tail -5 /var/log/apache2/error.log
apt install mariadb-server
systemctl status mariadb
mysql
cat /root/db.sql
mysql < /root/db.sql
mysql -e "USE ingenieria; SELECT * FROM alumnos;"
poweroff
ip addr
ip route
cat /etc/resolv.conf
cat /etc/network/interfaces
cp /etc/network/interfaces /etc/network/interfaces.bak
nano /etc/network/interfaces
cat /etc/network/interfaces
nano /etc/network/interfaces
cat /etc/network/interfaces
systemctl restart networking
ip addr
ping -c 2 8.8.8.8
ping -c 2 google.com
poweroff
lsblk
poweroff
